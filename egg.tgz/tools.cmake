# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(autosar-check src/autosar-check.cpp)
set_property(TARGET autosar-check PROPERTY CXX_STANDARD 11)
target_link_libraries(autosar-check lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(ninja-build src/ninja-build.cpp)
set_property(TARGET ninja-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ninja-build lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(drmemory src/drmemory.cpp)
set_property(TARGET drmemory PROPERTY CXX_STANDARD 11)
target_link_libraries(drmemory lionss pthread)

add_executable(cpplint src/cpplint.cpp)
set_property(TARGET cpplint PROPERTY CXX_STANDARD 11)
target_link_libraries(cpplint lionss pthread)

add_executable(reuse-lint src/reuse-lint.cpp)
set_property(TARGET reuse-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(reuse-lint lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(sphinx-docs src/sphinx-docs.cpp)
set_property(TARGET sphinx-docs PROPERTY CXX_STANDARD 11)
target_link_libraries(sphinx-docs lionss pthread)

add_executable(tsan src/tsan.cpp)
set_property(TARGET tsan PROPERTY CXX_STANDARD 11)
target_link_libraries(tsan lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(lsan src/lsan.cpp)
set_property(TARGET lsan PROPERTY CXX_STANDARD 11)
target_link_libraries(lsan lionss pthread)

add_executable(valgrind-drd src/valgrind-drd.cpp)
set_property(TARGET valgrind-drd PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-drd lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(lcov-report src/lcov-report.cpp)
set_property(TARGET lcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(lcov-report lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(lldb-smoke src/lldb-smoke.cpp)
set_property(TARGET lldb-smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(lldb-smoke lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)


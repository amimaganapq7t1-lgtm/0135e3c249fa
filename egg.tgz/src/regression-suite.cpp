// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("regression suite\n", stdout);
  return lionss_run_workload("regression-suite");
}

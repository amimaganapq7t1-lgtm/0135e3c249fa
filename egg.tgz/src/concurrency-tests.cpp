// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("concurrency tests"); }
int main(){
  announce();
  return lionss_run_workload("concurrency-tests");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("reuse lint\n", stdout);
  return lionss_run_workload("reuse-lint");
}

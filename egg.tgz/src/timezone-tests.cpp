// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("timezone tests\n", stdout);
  return lionss_run_workload("timezone-tests");
}

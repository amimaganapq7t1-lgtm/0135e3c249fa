// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("big endian check"); }
int main(){
  announce();
  return lionss_run_workload("big-endian-check");
}
